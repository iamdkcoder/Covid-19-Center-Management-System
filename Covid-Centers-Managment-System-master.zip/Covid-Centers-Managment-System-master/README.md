# Covid-Centers-Managment-System

Suraj Zaware


Username  =         Admin

Password  =         Admin



Database file provide with this Setup
first setup database and then install this this Softwre!!!!

Process To Setup Database

1-install xamp (or any software tht provide phpmyadmin functionality)

2-After installation firstly start Apache and MySQL server

3-Open Browser And past this link in browser  "http://localhost/phpmyadmin/"

4- Create a new Database named as "covidcenter"

5- Click on database then go to import tab

6- select database file provided with setup and click on go (database type select sql)

7- In database you will see all tables 

database installed succesfully


